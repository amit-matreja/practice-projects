# Python_basic_codes_1
Examples of Python_basic_codes
